from cc3d.core.PySteppables import *
import random
import math
import numpy as np
import os

# random.seed(54326)

save_dir = "~/GCR_saved_files/33_cellData_V50/" # ~ refers to C:/users/qzhan31

# Parameters
zLayer = 11
zInterval = 5

xOffset = 25

initialAffinity_mean = 5
deviation = 0
score_scaling_factor = 0.25
initialAffinity_start = initialAffinity_mean - deviation
initialAffinity_end = initialAffinity_mean + deviation
#initialAffinity = 5
Affinity_threshold_for_differentiation = 10

lethalMutationProb = 0.3 #0.2
badMutationProb = 1/3 #0.45 #1/3
goodMutationProb = 1/3 #0.45 #1/3

BCell_initial_count = 200
BCell_targetVolume = 50        #16
BCell_lambdaVolume = 10

# Parameters for random B cell threshold volume to trigger cytokinesis
m1 = BCell_targetVolume * 2
v1 = 5
mu1 = math.log((m1**2)/math.sqrt(v1+m1**2))
sigma1 = math.sqrt(math.log(v1/(m1**2)+1))

# Parameters for asymmetrical cell division
m2 = 0.5
v2 = 0.0002
mu2 = math.log((m2**2)/math.sqrt(v2+m2**2))
sigma2 = math.sqrt(math.log(v2/(m2**2)+1))


CRC_count = 16
FDC_count = 16 # originally 10
Tfh_count = 7 # originally 30

CXCL12_lambda_factor = 200      #20
CXCL13_lambda_factor = 100      #8
AP4_threshold = 50 #20.  AP4 level cannot be too low, say 25, because there is almost always a daught cell that does not degrade AP4 fast enough by chance, causing high burst size.
LETTERS = ['A', 'C', 'G', 'T']

SEQUENCE_LENGTH = 10
Adjust_factor = 10 # Adjust_factor = 100/SEQUENCE_LENGTH
ANTIGEN_SEQUENCE = "ATGCTCTGGA"
#ANTIGEN_SEQUENCE = "ATGCT"
combos = [] # all possible letter sequences
badKeys = ["SBMLSolver", "__sbml_fetcher", "store", "ratio", "Split", "mutations", "initialAffinity", "AntibodySequence", "numMutation"] # dictionary keys to not save
dictOutput = ['CXCR4', 'CXCR5', 'FOXO1', 'cRel', 'MYC', 'AP4', 'survival', 'pMHCII', 'AKT', 'cellCycleCommitted', 'CD40', 'delay_switch', 'mTOR', 'caspase3', 'RelA', 'Blimp1'] # model outputs to save
mitosisVariables = ['CXCR4', 'CXCR5', 'FOXO1', 'cRel', 'MYC', 'survival', 'pMHCII', 'AKT', 'CD40', 'delay_switch', 'mTOR', 'caspase3', 'RelA', 'Blimp1'] # for mitosis binomial distribution. Note AP4 is not in the list to avoid the issue that AP4 does not decrease as expected due to randomly obtaining higher values during binominal sampling especially when AP4 gets down to low values
samplefreq = 15

doubleTime = 500 #400 # B cell doubling time in mcs

cellID_max = 0 # Use to track the highest cell ID ever exists

# for i in range(BCell_initial_count): # of cells
    # seq = ""
    # for j in range(SEQUENCE_LENGTH): # number of letters
        # seq += random.choice(LETTERS)
    # combos.append(seq)
    
combos.append("TGCTCTGCAT") # 0
combos.append("AGCTCTGCAT") # 1
combos.append("ATCTCTGCAT") # 2
combos.append("ATGTCTGCAT") # 3
combos.append("ATGCCTGCAT") # 4
combos.append("ATGCTTGCAT") # 5
combos.append("ATGCTCGCAT") # 6
combos.append("ATGCTCTCAT") # 7
combos.append("ATGCTCTGAT") # 8
combos.append("ATGCTCTGGT") # 9
combos.append("ATGCTCTGGA") # 10

#combos.append("TGCTC") # 0
#combos.append("AGCTC") # 1
#combos.append("ATCTC") # 2
#combos.append("ATGTC") # 3
#combos.append("ATGCC") # 4
#combos.append("ATGCT") # 5

class GCR_48Steppable(SteppableBasePy):
    
    def __init__(self,frequency=1):

        SteppableBasePy.__init__(self,frequency)
        self.track_cell_level_scalar_attribute(field_name='affinityScore', attribute_name='affinityScore')
        self.track_cell_level_scalar_attribute(field_name='generation', attribute_name='Generation')
        self.track_cell_level_scalar_attribute(field_name='actualVolume', attribute_name='actualVolume')
        self.track_cell_level_scalar_attribute(field_name='targetVolume', attribute_name='targetVolume')


    def start(self):
        
        a = 99  #49 # Ellipse width
        b = 80 # Ellipse height
        
        # # Generating GC boundary
        # for angle in range(360):
            # theta = math.radians(angle)
            # x = a + a * math.cos(theta) + 1
            # y = b + b * math.sin(theta) + 19
            # self.cell_field[x:x+1,y:y+1,0] = self.new_cell(self.WALL)
        
        # Generating CRCs
        for x in range(1,8,2):
            if x == 1:
                for y in range(7-x, 11+x+1, 2): #9+x+1 is exclusive
                    for i in range(0, zLayer, zInterval):
                        z = random.choice(list(range(0,zLayer)))
                        self.cell_field[x*10+xOffset:x*10+6+xOffset, y*10+7:y*10+7+6,z] = self.new_cell(self.CRC)
            elif x == 5:
                #for y in range(9-x, 9+x+1, 2): #9+x+1 is exclusive
                for y in [4, 6, 12, 14]:
                    for i in range(0, zLayer, zInterval):
                        z = random.choice(list(range(0,zLayer)))
                        self.cell_field[x*10+xOffset:x*10+6+xOffset, y*10+7:y*10+7+6,z] = self.new_cell(self.CRC)
            elif x == 3:
                for y in range(9-x, 12+x, 2):
                #for y in [6, 8, 12, 14]:
                    for i in range(0, zLayer, zInterval):
                        z = random.choice(list(range(0,zLayer)))
                        self.cell_field[x*10+xOffset:x*10+6+xOffset, y*10-3:y*10-3+6,z] = self.new_cell(self.CRC)
            
            elif x == 7:
                #for y in range(11-x, 10+x, 2):
                #for y in [4, 6, 8, 12, 14, 16]:
                #for y in [4, 16]: 
                for y in [5, 15]: 
                    for i in range(0, zLayer, zInterval):
                        z = random.choice(list(range(0,zLayer)))
                        self.cell_field[x*10+xOffset:x*10+6+xOffset, y*10-3:y*10-3+6,z] = self.new_cell(self.CRC)
            
        
        
        
        # Generating FDCs and Tfh cells      
        
        for x in range(19,11,-2):
            
            if x == 19:
                for y in range(7-(20-x), 11+(20-x)+1, 2):
                    x1 = x*10-6
                    x2 = x1+6
                    y1 = y*10+7
                    y2 = y1+6
                    for i in range(0, zLayer, zInterval):
                        z = random.choice(list(range(0,zLayer)))
                        newFDC = self.new_cell(self.FDC)
                        self.cell_field[x1+xOffset:x2+xOffset, y1:y2,z] = newFDC
                        newFDC.dict["AntigenSequence"] = ANTIGEN_SEQUENCE
                            
                        if y in [8,10]:
                            for j in range(1): # 1 inner Tfh cells per FDC
                                offsetx = j*12-2#random.choice([-6,-5,5,6])
                                offsety = 4#random.choice([-6,-5,5,6])
                                self.cell_field[x1+offsetx-3+xOffset:x1+offsetx-3+4+xOffset, y1+offsety-3:y1+offsety-3+4,z] = self.new_cell(self.TCELL)
            
            elif x == 15:
                #for y in range(9-(20-x), 9+(20-x)+1, 2):
                for y in [4, 6, 12, 14]:
                    x1 = x*10-6
                    x2 = x1+6
                    y1 = y*10+7
                    y2 = y1+6
                    for i in range(0, zLayer, zInterval):
                        z = random.choice(list(range(0,zLayer)))
                        newFDC = self.new_cell(self.FDC)
                        self.cell_field[x1+xOffset:x2+xOffset, y1:y2,z] = newFDC
                        newFDC.dict["AntigenSequence"] = ANTIGEN_SEQUENCE
                    
                        if y in [6, 12]:
                            for j in range(2): # 2 Tfh cells per FDC
                                offsetx = j*12-2#random.choice([-6,-5,5,6])
                                offsety = 4#random.choice([-6,-5,5,6])
                                self.cell_field[x1+offsetx-3+xOffset:x1+offsetx-3+4+xOffset, y1+offsety-3:y1+offsety-3+4,z] = self.new_cell(self.TCELL)
    
            elif x == 17:
                for y in range(9-(20-x), 12+(20-x), 2):
                #for y in [6, 8, 12, 14]:
                    x1 = x*10-6
                    x2 = x1+6
                    y1 = y*10-3
                    y2 = y1+6
                    for i in range(0, zLayer, zInterval):
                        z = random.choice(list(range(0,zLayer)))
                        newFDC = self.new_cell(self.FDC)
                        self.cell_field[x1+xOffset:x2+xOffset, y1:y2,z] = newFDC
                        newFDC.dict["AntigenSequence"] = ANTIGEN_SEQUENCE
                        
                        if y in [8,10,12]:
                            for j in range(2): # 2 Tfh cells per FDC
                                offsetx = j*12-2#random.choice([-6,-5,5,6])
                                offsety = 4#random.choice([-6,-5,5,6])
                                self.cell_field[x1+offsetx-3+xOffset:x1+offsetx-3+4+xOffset, y1+offsety-3:y1+offsety-3+4,z] = self.new_cell(self.TCELL)
            
            elif x == 13:
                #for y in range(11-(20-x), 10+(20-x), 2): 
                #for y in [4, 6, 8, 12, 14, 16]:
                #for y in [4, 16]: 
                for y in [5, 15]:
                    x1 = x*10-6
                    x2 = x1+6
                    y1 = y*10-3
                    y2 = y1+6
                    for i in range(0, zLayer, zInterval):
                        z = random.choice(list(range(0,zLayer)))
                        newFDC = self.new_cell(self.FDC)
                        self.cell_field[x1+xOffset:x2+xOffset, y1:y2,z] = newFDC
                        newFDC.dict["AntigenSequence"] = ANTIGEN_SEQUENCE
                    
                        for j in range(0): # 0 Tfh cells per FDC
                            offsetx = j*12-2#random.choice([-6,-5,5,6])
                            offsety = 4#random.choice([-6,-5,5,6])
                            self.cell_field[x1+offsetx-3+xOffset:x1+offsetx-3+4+xOffset, y1+offsety-3:y1+offsety-3+4,z] = self.new_cell(self.TCELL)
                
        
       
        
        
        
        
        # Generating initial B cells
        count = 0
        while count < BCell_initial_count:
            x = random.uniform(0, 2*a)
            y = random.uniform(0, 2*b)
            if (x - a - 1)**2 / a**2 + (y - b - 19)**2 / b**2 < 0.9 and x > 60 and x < 130:
                seederBCell = self.new_cell(self.BCELL)
                
                z = random.choice(list(range(0,zLayer)))
                self.cell_field[x+xOffset:x+8+xOffset,y:y+8,z] = seederBCell
                
                seederBCell.targetVolume = BCell_targetVolume
                seederBCell.lambdaVolume = BCell_lambdaVolume    #4
                
                # Assign SBML model
                self.add_antimony_to_cell(model_string=modelString, model_name='BCellNetwork', cell=seederBCell, integrator='gillespie')
                #self.add_antimony_to_cell_types(model_string=modelString, model_name='BCellNetwork', cell_types=[self.BCELL], integrator='gillespie')
             
                
                # Initialize chemotaxis parameters
                cd12 = self.chemotaxisPlugin.addChemotaxisData(seederBCell, "CXCL12")
                #cd12.setLambda(0) 
                #cd12.setSaturationCoef(100)
                #cd12.setSaturationLinearCoef(0.1)
                cd12.setLogScaledCoef(0.01)
                #cd12.assignChemotactTowardsVectorTypes([self.cell_type.Medium])
                
                cd13 = self.chemotaxisPlugin.addChemotaxisData(seederBCell, "CXCL13") 
                #cd13.setLambda(CXCL13_lambda_factor*100)
                
                #The simple method, i.e., lambda*(x1-x2), will not move cells when they are in low gradient areas
                #cd13.setSaturationCoef(1) #This method tends to cause cells halt at a particular xCOM
                #cd13.setSaturationLinearCoef(0.5) #This method tends to cause cells migration in a single file or line
                cd13.setLogScaledCoef(0.01)
                
                #cd13.assignChemotactTowardsVectorTypes([self.cell_type.Medium])
                              
                
                # Initialize B cell dictionary values
                seederBCell.dict["mcs"] = 0
                initialAffinity = random.choice(list(np.arange(initialAffinity_start, initialAffinity_end+score_scaling_factor, score_scaling_factor)))
                seederBCell.dict["AntibodySequence"] = combos[int(initialAffinity)] # Initialize antibody sequences
                seederBCell.dict["initialAffinity"] = initialAffinity
                seederBCell.dict["affinityThreshold"] = Affinity_threshold_for_differentiation
                seederBCell.dict["affinityScore"] = initialAffinity
                seederBCell.dict["mutations"] = [] # Use sequence of -1, 0, or 1 to indicate each mutation and whether it causes decrease, no change, or increase in affinity
                
                seederBCell.dict["cellID"] = seederBCell.id
                global cellID_max
                if cellID_max < seederBCell.dict["cellID"]:
                    cellID_max = seederBCell.dict["cellID"]
                
                
                seederBCell.dict["motherID"] = seederBCell.id # B cells of generation 0 using their own IDs as mother ID
                seederBCell.dict["seederID"] = seederBCell.id # Use to track B cell clones
                seederBCell.dict["Generation"] = 0 # Number of cells in each generation
                seederBCell.dict["numMutation"] = 0 # Records cumulative number of cell mutations
                
                seederBCell.dict["store"] = [] # Storing data for export
                
                seederBCell.dict["deathMutation"] = 0
                seederBCell.dict["Alive"] = 1
                
                seederBCell.dict["selectionDecision"] = 0 # Positive selection not carried out
                
                seederBCell.dict["Cytokinesis"] = 0
                
                seederBCell.dict["plasmaCell"] = 0
                
                seederBCell.dict["thresholdVolumeDivision"] = round(np.random.lognormal(mu1, sigma1),2) #A random threshold volume to trigger cytokinesis
                
                seederBCell.dict["actualVolume"] = seederBCell.volume # Storing actual volume for output
                seederBCell.dict["targetVolume"] = seederBCell.targetVolume # Storing target volume for output
                seederBCell.dict["actualSurface"] = seederBCell.surface # Storing actual surface area for output
                
        
                # saving header to file
                toSave = ""
                for var in seederBCell.dict:
                    if var not in badKeys:
                        toSave += str(var) + " "
                toSave += "xCOM yCOM zCOM "
                for key in seederBCell.sbml.BCellNetwork.keys():
                    if key in dictOutput:
                        toSave += str(key) + " "
                fileName = str(seederBCell.dict["Generation"]) + "_" + str(seederBCell.dict["motherID"]) + "_" + str(seederBCell.dict["cellID"])
                dir = save_dir + str(fileName) + ".txt"
                f = open(os.path.expanduser(dir), "a") # open text file
                f.write(toSave)
                f.write("\n")
                
                
                count += 1

                

        # Initialize Random Sequence
                        # if "Sequence" not in cell.dict:
                            # cell.dict["Sequence"] = combos[iteration]
                            
                            # # record individual mutations.
                            # cell.dict["sequenceRecord"] = []
                            # cell.dict["sequenceRecord"].append(combos[iteration])
                            
                            # if (go == 1):
                                # iteration += 1
                            
                            # string = cell.dict["Sequence"]
                            # newScore = 0
                            # for i in range(len(string)):
                                # if (string[i] == ANTIGEN_SEQUENCE[i]):
                                    # newScore += 1
                            # cell.dict["affinityScore"] = newScore        
    
    def step(self,mcs):
        
        cells = 0 # total number of B cells
        #generations = [] # number of B cells in each generation
        
                  
        # Main action
        for cell in self.cell_list:
            if cell.type == self.BCELL: 
                try:
                    if cell.sbml.BCellNetwork:
                        # This is to evaluate whether the associated SBML model exists to overcome the potential issue that when a cell and its SBML model are deleted, 
                        # the SBML model is gone immediately but the cell may still linger for a while 
                        # (which may explain the ghost effect).
                        
                        cells += 1
                        #generations.append(cell.dict["Generation"]) # Number of cells in each generation
                        cell.dict["actualVolume"] = cell.volume # Storing actual volume for output
                        cell.dict["targetVolume"] = round(cell.targetVolume, 2) # Storing target volume for output
                        cell.dict["actualSurface"] = cell.surface # Storing actual surface area for output
                        
                        delete_cell = 0
                        
                    # Check neighbor cells touched
                        
                        neighbor_list = self.get_cell_neighbor_data_list(cell)
                        neighbor_count_by_type_dict = neighbor_list.neighbor_count_by_type()
                        
                        # FDC cell type id is 2
                        touchFDC = False
                        if "2:" in str(neighbor_count_by_type_dict):
                            touchFDC = True
                            #print(neighbor_count_by_type_dict)
                        
                        
                        # neighbor_list = self.get_cell_neighbor_data_list(cell)
                        # neighbor_count_by_type_dict = neighbor_list.neighbor_count_by_type()
                        
                        # CRC cell type id is 3
                        touchCRC = False
                        if "3:" in str(neighbor_count_by_type_dict):
                            touchCRC = True
                            
                        
                        # neighbor_list = self.get_cell_neighbor_data_list(cell)
                        # neighbor_count_by_type_dict = neighbor_list.neighbor_count_by_type()
                        
                        # T cell type id is 4
                        touchTC = False
                        if "4:" in str(neighbor_count_by_type_dict):
                            touchTC = True
                        

                                
                    # BCR signaling upon touching FDC
                        if touchFDC == True and cell.dict["affinityScore"]>=0: #Becasue -1 is used to mark lethally mutated cells, this condition is necessary to prevent negative pMHCII and subsequent consequences when the lethally mutated cell is born in LZ.
                            
                          # Calculate BCR/antibody affinity and store it as affinityScore in cell dictionary  
                            """
                            antibodyString = cell.dict["AntibodySequence"] # Retrieve antibody sequence
                            for neighbor_tuple in self.get_cell_neighbor_data_list(cell): # Find B cell neighbors
                                if neighbor_tuple[0]: # Check if a neighbor exists
                                    FDCid = neighbor_tuple[0].id # tuple = (neighbor id, common surface area)
                                    neighborCell = self.fetch_cell_by_id(FDCid)
                                    if (neighborCell.type == 2): # FDC is type 2
                                        antigenString = neighborCell.dict["AntigenSequence"] # Obtain antigen sequence stored in FDC
                            newScore = 0
                            for i in range(len(antibodyString)):
                                if (antibodyString[i] == antigenString[i]):
                                    newScore += 1
                            cell.dict["affinityScore"] = newScore
                            """
                                                        
                            cell.sbml.BCellNetwork['pMHCII'] = round(Adjust_factor * cell.dict["affinityScore"]) # MHC_II antigen density is proportional to affinity score; rounding is needed to prevent fractional values
                            
                            cell.sbml.BCellNetwork['s15'] = Adjust_factor * cell.dict["affinityScore"] # Turn on AKT which is proportional to affinity score
                        
                            if cell.dict["affinityScore"] > Affinity_threshold_for_differentiation:
                                cell.sbml.BCellNetwork['s27'] = 1 #Switch on RelA
                        else:
                            cell.sbml.BCellNetwork['s15'] = 0 # Turn off AKT
                    
                    
                    # CD40 signaling upon touching T Cell 
                        if touchTC == True:
                            cell.sbml.BCellNetwork['s19'] = 1 # Turn on CD40 signaling
                            
                        else:
                            cell.sbml.BCellNetwork['s19'] = 0 # Turn off CD40
                    
                       
                    # Determining whether B cell is positively selected based on pMHCII density after mTOR reaches a certain level. mTOR here is to provide enough time for B cells to stay in LZ to integrate sufficiently long Myc signal 
                        if cell.sbml.BCellNetwork['mTOR'] > 100 and cell.dict["selectionDecision"] == 0:
                            #survival_chance = (cell.sbml.BCellNetwork['pMHCII']/100)**2 # If B Cell has already contacted FDC, MHC_II antigen density will be between 0 and 100. Use squared so that affinity score 5 survival odd is 0.25, score 9 survival odd is 0.81...
                            survival_chance = (cell.sbml.BCellNetwork['pMHCII']/100)
                            rand = random.random() # Create a random number between 0 and 1
                            if rand < survival_chance:
                                # Turn off death timer and reset 'survival'
                                cell.sbml.BCellNetwork['s100'] = 0;
                                cell.sbml.BCellNetwork['survival'] = 100;
                                
                                # Tentatively enforce AP4 proportional to pMHCII
                                #cell.sbml.BCellNetwork['AP4'] = 2 * cell.sbml.BCellNetwork['pMHCII']
                                
                                # Cell committed to cell cycle
                                cell.sbml.BCellNetwork['cellCycleCommitted'] = 1
                            
                            # Selection decision carried out
                            cell.dict["selectionDecision"] = 1
                            

                        
                    # Actions if cell cycle is committed    
                        if cell.sbml.BCellNetwork['cellCycleCommitted'] == 1:
                                
                            if cell.sbml.BCellNetwork['delay_switch'] > 50: # Cell growth delay.
                            
                                cell.targetVolume = cell.targetVolume * math.exp(math.log(2)/doubleTime) # MYC initiated growth is slow to start
                            
                            cell.sbml.BCellNetwork['s14'] = 1 # To degrade surface pMHCII gradually.
                            
                            
                    # Obtain and update chemotaxis parameters
                        cd12 = self.chemotaxisPlugin.getChemotaxisData(cell, "CXCL12")
                        cd13 = self.chemotaxisPlugin.getChemotaxisData(cell, "CXCL13")
                        cd12.setLambda(CXCL12_lambda_factor*cell.sbml.BCellNetwork['CXCR4'])
                        cd13.setLambda(CXCL13_lambda_factor*cell.sbml.BCellNetwork['CXCR5']) 
                        
                            
                    # Cell death
                        if cell.sbml.BCellNetwork['survival'] < 50 or cell.sbml.BCellNetwork['caspase3'] > 50: #The ['caspase3'] > 50 condition is used to initiate cell killing due to damaging mutation
                            
                            cell.dict["Alive"] = 0
                            
                            delete_cell = 1
                            

                    # Terminal differentiation to plasma cells
                        if cell.sbml.BCellNetwork['Blimp1'] > 50:
                            cell.dict["plasmaCell"] = 1
                            cell.sbml.BCellNetwork['cellCycleCommitted'] = 0
                            
                            delete_cell = 1
                            


                    # Saving to files regularly
                        if (mcs % samplefreq == 0) or (delete_cell == 1):
                            
                        # Saving variables to array first    
                            cell.dict["mcs"] = mcs
                            toSave = ""
                            for var in cell.dict:
                                if var not in badKeys:
                                    toSave += str(cell.dict[var]) + " "
                                    
                            toSave += str(round(cell.xCOM,2)) + " " + str(round(cell.yCOM,2)) + " " + str(round(cell.zCOM,2)) + " "
                            
                            for key in cell.sbml.BCellNetwork.keys():
                                if key in dictOutput:
                                    toSave += str(cell.sbml.BCellNetwork[key]) + " "
                            #cell.dict["store"].append(str(mcs) + " " + str(toSave))
                            cell.dict["store"].append(str(toSave))
                        
                        # saving to txt file
                            for i in range(len(cell.dict["store"])):
                                fileName = str(cell.dict["Generation"]) + "_" + str(cell.dict["motherID"]) + "_" + str(cell.dict["cellID"])
                                dir = save_dir + str(fileName) + ".txt"
                                f = open(os.path.expanduser(dir), "a") # open text file in append mode for writing
                                f.write(cell.dict["store"][i])
                                f.write("\n")
                            cell.dict["store"] = []

                        
                    # delete the cell marked death or differentiation
                        if delete_cell == 1:
                            self.delete_sbml_from_cell(model_name='BCellNetwork',cell=cell) # according to manual delete_cell() will automatically delete the SBML model as well but the model crashes without explicitly invoking sbml model deletion
                            self.delete_cell(cell)
                               
                            
                except KeyError:
                    print("SBML does not exist!")
        
        # """
        # # print number of cells in each generation
        # gentotal = []
        # generations.sort()
                
        # for gen in range(len(generations)+1): #generations[-1]+1
            # gentotal.append(0)
            # for num in generations:
                # if num == gen:
                    # gentotal[gen] += 1
        
        # x = 1
        # for num in gentotal:
            # #print("Cells in generation " + str(x) + ": " + str(num))
            # x += 1
        # """



class MitosisSteppable(MitosisSteppableBase):
    def __init__(self, frequency=1):
        
        MitosisSteppableBase.__init__(self, frequency)
        
        self.set_parent_child_position_flag(0)

    def step(self, mcs):
        cells_to_divide = []
        for cell in self.cell_list:
            if cell.type == self.BCELL:
                
                if cell.volume >= cell.dict["thresholdVolumeDivision"]:
                    
                    cell.dict["Cytokinesis"] = 1
                    cells_to_divide.append(cell)
                    
                # saving to file
                    #if (mcs % samplefreq != 0): #Do not use this. it seems that the file saving in the main steppable occurs before the mitosis steppable is executed.only need to save when mcs is not multiple of samplefreq to avoid double recording
                        
                    # saving variables to array first
                    cell.dict["mcs"] = mcs
                    toSave = ""
                    for var in cell.dict:
                        if var not in badKeys:
                            toSave += str(cell.dict[var]) + " "
                    toSave += str(round(cell.xCOM,2)) + " " + str(round(cell.yCOM,2)) + " " + str(round(cell.zCOM,2)) + " "
                    for key in cell.sbml.BCellNetwork.keys():
                        if key in dictOutput:
                            toSave += str(cell.sbml.BCellNetwork[key]) + " "
                    #cell.dict["store"].append(str(mcs) + " " + str(toSave))
                    cell.dict["store"].append(str(toSave))
                
                    # saving to txt file
                    for i in range(len(cell.dict["store"])):
                        fileName = str(cell.dict["Generation"]) + "_" + str(cell.dict["motherID"]) + "_" + str(cell.dict["cellID"])
                        dir = save_dir + str(fileName) + ".txt"
                        f = open(os.path.expanduser(dir), "a") # open text file
                        f.write(cell.dict["store"][i])
                        f.write("\n")
                    cell.dict["store"] = []    
                    

        # Cytokinesis occurs
        for cell in cells_to_divide:
            self.divide_cell_random_orientation(cell) #This step only create a daughter cell out of the parent morphologically, no other model variables or dict copied.
        
        
    def update_attributes(self):
        
      # reset cell cycle token and cell death timer
        if self.parent_cell.sbml.BCellNetwork['AP4'] < AP4_threshold:
            self.parent_cell.sbml.BCellNetwork['cellCycleCommitted'] = 0
            self.parent_cell.sbml.BCellNetwork['mTOR'] = 0
            self.parent_cell.sbml.BCellNetwork['delay_switch'] = 0
            self.parent_cell.sbml.BCellNetwork["survival"] = 100 #Reset to 100 to prevent those cells inheriting low levels of survival by chance after multiple rounds of division from dying too fast.
            
            # Turn on death timer
            self.parent_cell.sbml.BCellNetwork['s100'] = 1;
            
            # Stop degrading pMHCII, although it is not expressed yet at this moment
            self.parent_cell.sbml.BCellNetwork['s14'] = 0
        
      # Two daughter cells first inherit all things equally
        self.clone_parent_2_child()
        self.child_cell.type = self.BCELL
        
        
      # Asymmetrical cell division and binomial distribution of molecules among the two daughter cells
        split_ratio = np.random.lognormal(mu2, sigma2)
        
        # Using log-normal distribution to split cell volume
        parent_cell_pre_division_volume = self.parent_cell.volume * 2 # after self.divide_cell_random_orientation(cell), the parent cell (daughter 1 volume is already reducd by half.
        self.parent_cell.targetVolume = parent_cell_pre_division_volume * split_ratio # Future daughter cell 1
        self.child_cell.targetVolume = parent_cell_pre_division_volume * (1 - split_ratio) # Future daughter cell 2
        
        # Assign new threshold volume for division
        self.child_cell.dict["thresholdVolumeDivision"] = round(np.random.lognormal(mu1, sigma1),2) #A random threshold volume to trigger cytokinesis
        self.parent_cell.dict["thresholdVolumeDivision"] = round(np.random.lognormal(mu1, sigma1),2) #A random threshold volume to trigger cytokinesis
        
        # Using binomial distribution to split variables between two daughter cells
        for key in self.parent_cell.sbml.BCellNetwork.keys():
            if key in mitosisVariables: #Note AP4 is not in the list to avoid the issue that AP4 does not decrease as expected due to randomly obtaining higher values during binominal sampling especially when AP4 gets down to low values
                
                # To troubleshoot for "ValueError: n < 0"
                if self.parent_cell.sbml.BCellNetwork[key] < 0:
                    print(str(self.parent_cell.dict["cellID"]))
                    print(key + str(self.parent_cell.sbml.BCellNetwork[key]))
                
                Variable_daughter1 = np.random.binomial(self.parent_cell.sbml.BCellNetwork[key]*2, split_ratio)
                Variable_daughter2 = self.parent_cell.sbml.BCellNetwork[key]*2 - Variable_daughter1
  
                self.parent_cell.sbml.BCellNetwork[key] = Variable_daughter1
                self.child_cell.sbml.BCellNetwork[key] = Variable_daughter2
                

        #print("AP4_1 = " + str(self.parent_cell.sbml.BCellNetwork["AP4"]))
        #print("AP4_2 = " + str(self.child_cell.sbml.BCellNetwork["AP4"]))
        
      # Reset Cytokinesis
        self.child_cell.dict["Cytokinesis"] = 0
        self.parent_cell.dict["Cytokinesis"] = 0
        
      # Reset selectionDecision
        self.child_cell.dict["selectionDecision"] = 0
        self.parent_cell.dict["selectionDecision"] = 0
        
      # Update generation number
        self.child_cell.dict["Generation"] = self.parent_cell.dict["Generation"] + 1
        self.parent_cell.dict["Generation"] += 1
        
      # Update motherID
        self.child_cell.dict["motherID"] = self.parent_cell.dict["cellID"]
        self.parent_cell.dict["motherID"] = self.parent_cell.dict["cellID"]
        
        
      # Update cellID
        
        # Old code
        # curr = 0
        # for cell in self.cell_list:
            # if cell.type == self.BCELL:
                # if cell.dict["cellID"] > curr:
                    # curr = cell.dict["cellID"]
        # self.parent_cell.dict["cellID"] = curr+1
        # self.child_cell.dict["cellID"] = curr+2
        
        # New code
        global cellID_max
        self.parent_cell.dict["cellID"] = cellID_max + 1
        self.child_cell.dict["cellID"]  = cellID_max + 2
        cellID_max = self.child_cell.dict["cellID"]
        
        
        
      # Mutate two daughter cells
        
                
        # Mutate daughter cell 1
        rand = random.random() # Create a random number between 0 and 1
        
        if rand < lethalMutationProb:
            self.parent_cell.dict["mutations"].append(4) #Use 4 to indicate death due to damaging mutation
            self.parent_cell.dict["deathMutation"] = 1
            self.parent_cell.dict["affinityScore"] = -1
            self.parent_cell.sbml.BCellNetwork['s25'] = 1 #Turn on caspase 3-mediated apoptosis
            
        else:
            rand = random.random() # Create a random number between 0 and 1    
            
            if rand < badMutationProb:
                self.parent_cell.dict["mutations"].append(-1)
                mutationDirection = -1
            if rand >= badMutationProb and rand < (1-goodMutationProb):
                self.parent_cell.dict["mutations"].append(0)
                mutationDirection = 0
            if rand >= (1-goodMutationProb):
                self.parent_cell.dict["mutations"].append(1)
                mutationDirection = 1
        
            new_affinityScore = self.parent_cell.dict["affinityScore"] + mutationDirection * score_scaling_factor * random.choice([1,2])    # Update affinity score with 1-unit or 2-unit change
            if new_affinityScore < 0: # To ensure minimal affinityScore is 0. 
                new_affinityScore = 0
            self.parent_cell.dict["affinityScore"] = new_affinityScore    
        
        self.parent_cell.dict["numMutation"] += 1 # Record number of mutations
        
        
        # Mutate daughter cell 2
        rand = random.random() # Create a random number between 0 and 1
        
        if rand < lethalMutationProb:
            self.child_cell.dict["mutations"].append(4) #Use 4 to indicate death due to damaging mutation
            self.child_cell.dict["deathMutation"] = 1
            self.child_cell.dict["affinityScore"] = -1
            self.child_cell.sbml.BCellNetwork['s25'] = 1 #Turn on caspase 3-mediated apoptosis
            
        else:
            rand = random.random() # Create a random number between 0 and 1    
                
            if rand < badMutationProb:
                self.child_cell.dict["mutations"].append(-1)
                mutationDirection = -1
            if rand >= badMutationProb and rand < (1-goodMutationProb):
                self.child_cell.dict["mutations"].append(0)
                mutationDirection = 0
            if rand >= (1-goodMutationProb):
                self.child_cell.dict["mutations"].append(1)
                mutationDirection = 1

            new_affinityScore = self.child_cell.dict["affinityScore"] + mutationDirection * score_scaling_factor * random.choice([1,2])    # Update affinity score with 1-unit or 2-unit change
            if new_affinityScore < 0: # To ensure minimal affinityScore is 0. 
                new_affinityScore = 0
            self.child_cell.dict["affinityScore"] = new_affinityScore  

        self.child_cell.dict["numMutation"] += 1 # Record number of mutations
        
        
        
        
        
        
        """
        #Saving to files for the two daughter cells
        
        # saving to array for daughter 1
        self.parent_cell.dict["mcs"] = +1 #Add 1 mcs step forward to the time point of cytokinesis as the daughter cell birth time. This may help to avoid double-counting number of cells at this moment if no +1 is used.
        toSave = ""
        for var in self.parent_cell.dict:
            if var not in badKeys:
                toSave += str(self.parent_cell.dict[var]) + " "
        toSave += str(round(self.parent_cell.xCOM,2)) + " " + str(round(self.parent_cell.yCOM,2)) + " "
        for key in self.parent_cell.sbml.BCellNetwork.keys():
            if key in dictOutput:
                toSave += str(self.parent_cell.sbml.BCellNetwork[key]) + " "
        self.parent_cell.dict["store"].append(str(toSave))
    
        # saving to file for daughter 1
        for i in range(len(self.parent_cell.dict["store"])):
            fileName = str(self.parent_cell.dict["Generation"]) + "_" + str(self.parent_cell.dict["motherID"]) + "_" + str(self.parent_cell.dict["cellID"])
            dir = save_dir + str(fileName) + ".txt"
            f = open(os.path.expanduser(dir), "a") # open text file
            f.write(self.parent_cell.dict["store"][i])
            f.write("\n")
        self.parent_cell.dict["store"] = []
        
        
        # saving to array for daughter 2
        self.child_cell.dict["mcs"] = +1 #Add 1 mcs step forward to the time point of cytokinesis as the daughter cell birth time. This may help to avoid double-counting number of cells at this moment if no +1 is used.        
        toSave = ""
        for var in self.child_cell.dict:
            if var not in badKeys:
                toSave += str(self.child_cell.dict[var]) + " "
        toSave += str(round(self.child_cell.xCOM,2)) + " " + str(round(self.child_cell.yCOM,2)) + " "
        for key in self.child_cell.sbml.BCellNetwork.keys():
            if key in dictOutput:
                toSave += str(self.child_cell.sbml.BCellNetwork[key]) + " "
        self.child_cell.dict["store"].append(str(toSave))
    
        # saving to file for daughter 2
        for i in range(len(self.child_cell.dict["store"])):
            fileName = str(self.child_cell.dict["Generation"]) + "_" + str(self.child_cell.dict["motherID"]) + "_" + str(self.child_cell.dict["cellID"])
            dir = save_dir + str(fileName) + ".txt"
            f = open(os.path.expanduser(dir), "a") # open text file
            f.write(self.child_cell.dict["store"][i])
            f.write("\n")
        self.child_cell.dict["store"] = []
        """
        
        
        
        """
        sequence = self.parent_cell.dict["AntibodySequence"]
        
        # Mutate daughter cell 1
        indexToChange = random.randint(0,SEQUENCE_LENGTH-1) # Random 0 to SEQUENCE_LENGTH-1
        options = ['A', 'C', 'G', 'T']
        options.remove(sequence[indexToChange]) # Remove letter in chosen position from possible letters to mutate to
        holder = random.choice(options) # Choose letter to mutate to from remaining letters
        
        self.parent_cell.dict["AntibodySequence"] = sequence[:indexToChange] + str(holder) + sequence[indexToChange+1:] # Update antibody sequence
        self.parent_cell.dict["numMutation"] += 1 # Record # of mutations
        
        string = self.parent_cell.dict["AntibodySequence"] # Calculate affinity score
        newScore = 0
        for i in range(len(string)):
            if (string[i] == ANTIGEN_SEQUENCE[i]):
                newScore += 1
        self.parent_cell.dict["affinityScore"] = newScore
        

        # Mutate daughter cell 2
        indexToChange = random.randint(0,SEQUENCE_LENGTH-1) # Random 0 to SEQUENCE_LENGTH-1
        options = ['A', 'C', 'G', 'T']
        options.remove(sequence[indexToChange]) # Remove letter in chosen position from possible letters to mutate to
        holder = random.choice(options) # Choose letter to mutate to from remaining letters
        
        self.child_cell.dict["AntibodySequence"] = sequence[:indexToChange] + str(holder) + sequence[indexToChange+1:] # Update antibody sequence
        self.child_cell.dict["numMutation"] += 1 # Record # of mutations
        
        string = self.child_cell.dict["AntibodySequence"] # Calculate affinity score
        newScore = 0
        for i in range(len(string)):
            if (string[i] == ANTIGEN_SEQUENCE[i]):
                newScore += 1
        self.child_cell.dict["affinityScore"] = newScore
        """
      
        

class BCell_GRNSteppable(SteppableBasePy):
    def __init__(self, frequency=1):
        SteppableBasePy.__init__(self, frequency)
         

    def step(self, mcs):
        self.timestep_sbml()
        
        # For on-the-fly display purpose
        #for cell in self.cell_list:
            #if cell.type == self.BCELL and not mcs % 50:
                # #self.plot_win.add_data_point("cellVol", mcs, cell.volume)
                # self.plot_win.add_data_point("CXCR4_level", mcs, cell.sbml.BCellNetwork['CXCR4'])
                # self.plot_win.add_data_point("CXCR5_level", mcs, cell.sbml.BCellNetwork['CXCR5'])
                # self.plot_win.add_data_point("MYC_level", mcs, cell.sbml.BCellNetwork['MYC'])
                # self.plot_win.add_data_point("AP4_level", mcs, cell.sbml.BCellNetwork['AP4'])
                # print("hi") 
        
class VisualizationSteppable(SteppableBasePy):
    def __init__(self, frequency=1):
        SteppableBasePy.__init__(self, frequency)
        
        self.CXCR4 = self.create_scalar_field_cell_level_py("CXCR4")
        self.CXCR5 = self.create_scalar_field_cell_level_py("CXCR5")
        self.FOXO1 = self.create_scalar_field_cell_level_py("FOXO1")
        self.cRel = self.create_scalar_field_cell_level_py("cRel")
        self.MYC = self.create_scalar_field_cell_level_py("MYC")
        self.AP4 = self.create_scalar_field_cell_level_py("AP4")
        self.survival = self.create_scalar_field_cell_level_py("survival")
        self.pMHCII = self.create_scalar_field_cell_level_py("pMHCII")
        self.AKT = self.create_scalar_field_cell_level_py("AKT")
        self.cellCycleCommitted = self.create_scalar_field_cell_level_py("cellCycleCommitted")
        self.CD40 = self.create_scalar_field_cell_level_py("CD40")
        self.delay_switch = self.create_scalar_field_cell_level_py("delay_switch")
        self.mTOR = self.create_scalar_field_cell_level_py("mTOR")
        self.caspase3 = self.create_scalar_field_cell_level_py("caspase3")
        self.RelA = self.create_scalar_field_cell_level_py("RelA")
        self.Blimp1 = self.create_scalar_field_cell_level_py("Blimp1")
        


    def step(self, mcs):

        for cell in self.cell_list:
            if cell.type == self.BCELL and cell.dict["Alive"] != 0:
                self.CXCR4[cell] = cell.sbml.BCellNetwork['CXCR4']
                self.CXCR5[cell] = cell.sbml.BCellNetwork['CXCR5']
                self.FOXO1[cell] = cell.sbml.BCellNetwork['FOXO1']
                self.cRel[cell] = cell.sbml.BCellNetwork['cRel']
                self.MYC[cell] = cell.sbml.BCellNetwork['MYC']
                self.AP4[cell] = cell.sbml.BCellNetwork['AP4']
                self.survival[cell] = cell.sbml.BCellNetwork['survival']
                self.pMHCII[cell] = cell.sbml.BCellNetwork['pMHCII']
                self.AKT[cell] = cell.sbml.BCellNetwork['AKT']
                self.cellCycleCommitted[cell] = cell.sbml.BCellNetwork['cellCycleCommitted']
                self.CD40[cell] = cell.sbml.BCellNetwork['CD40']
                self.delay_switch[cell] = cell.sbml.BCellNetwork['delay_switch']
                self.mTOR[cell] = cell.sbml.BCellNetwork['mTOR']
                self.caspase3[cell] = cell.sbml.BCellNetwork['caspase3']
                self.RelA[cell] = cell.sbml.BCellNetwork['RelA']
                self.Blimp1[cell] = cell.sbml.BCellNetwork['Blimp1']



# Antimony Model
modelString = """model BCell_GNR()
R1: -> CXCR4; k1 * FOXO1^n1/(Kd1^n1+FOXO1^n1) * cellCycleCommitted; 
R2: CXCR4 ->; k2*CXCR4;

R3: -> CXCR5; k3;                       #k3 * (1-cellCycleCommitted);
R4: CXCR5 ->; k4*CXCR5; 

R5: -> FOXO1; k5 * (Etot5 - 0.5 * (Etot5 + AKT + Kd5 - ((Etot5 + AKT + Kd5)^2 - 4 * Etot5 * AKT)^0.5));
R6: FOXO1 ->; k6*FOXO1;        #k6*FOXO1 + k61 * FOXO1 * AKT/Kd61 * Kd62^n62/(Kd62^n62+cRel^n62); 

R7: -> cRel; k7*CD40;
R8: cRel ->; k8*cRel; 

R9: -> MYC; k9*cRel*Kd9/(Kd9+FOXO1);
R10: MYC ->; k10*MYC; 

R11: -> AP4; k11*MYC;
R12: AP4 ->; k12*AP4; 

R13: -> pMHCII; k13;
R14: pMHCII ->; s14*k14*pMHCII;

R15: -> AKT; s15*k15*(1-cellCycleCommitted);
R16: AKT ->; k16*AKT;

R17: -> cellCycleCommitted; k17;
R18: cellCycleCommitted ->; k18*cellCycleCommitted;

R19: -> CD40; s19*k19*pMHCII;
R20: CD40 ->; k20*CD40;

R21: -> delay_switch; k21*cellCycleCommitted;
R22: delay_switch ->; k22*delay_switch;

R23: -> mTOR; k23*MYC;
R24: mTOR ->; k24*mTOR/(Kd24+mTOR);

R25: -> caspase3; s25*k25;
R26: caspase3 ->; k26*caspase3;

R27: -> RelA; s27*k27;
R28: RelA ->; k28*RelA;

R29: -> Blimp1; k29*RelA;
R30: Blimp1 ->; k30*Blimp1;

R100: survival ->; s100*k100*survival; 

#CXCR4
k2 = 0.693 / 20;
k1 = 100*k2;

#CXCR5
k4 = 0.693 / 20;
k3 = 100*k4;

#FOXO1
k6 = 0.693 / 20; # 0.693 / 10
k5 = k6;

#cRel
k8 = 0.693 / 30; # 0.693 / 10
k7 = k8;

#Myc
k10 = 0.693 / 50; # 0.693 / 20
k9  = k10;

#AP4
k12 = 0.693 / 1200; #0.693 / 200; make sure that AP4 has long enough half-life to cover the delay switch and cell cycle length. 
k11 = 45*k12; #60*k12; #30*k12; #k11 = 12*k12, k11 = 6*k12;

#pMHCII
k13 = 0;
k14 = 0.693 / 100;
s14 = 0;

#AKT
k15 = k16;
k16 = 0.693 / 10;
s15 = 0

#cellCycleCommitted
k17 = 0;
k18 = 0;

#CD40
k20 = 0.693 / 10;
k19 = k20;
s19 = 0;

#delay_switch
k22 = 0.693 / 800;
k21 = 100*k22;

#mTOR
k24 = 1;
k23 = 0.18;

#caspase3, used for damaging mutation induced cell death
k26 = 0.693 / 50;
k25 = 100*k26;
s25 = 0;

#RelA
k28 = 0.693 / 10;
k27 = 100*k28;
s27 = 0;

#Blimp1
k30 = 0.693 / 50;
k29 = k30;


#survival (death timer)
k100 = 0.693 / 1000; #700
s100 = 1;


Kd1 = 20;
Kd5 = 1;
Kd9 = 100;
Kd24 = 0.1;
Kd61 = 100;
Kd62 = 25;

Etot5 = 100;

n1 = 5;
n62 = 5;

CXCR4 = 0;
CXCR5 = 100;
FOXO1 = 100;
cRel = 0;
MYC = 0;
AP4 = 0;
survival = 100;
pMHCII = 0;
AKT = 0;
cellCycleCommitted = 0;
CD40 = 0;
delay_switch = 0;
mTOR = 0;
caspase3 = 0;
RelA = 0;
Blimp1 = 0;
end"""




"""
# To achieve even chemoattractant field with auto-regulatory feedbck
class ChemoattractantSecretionSteppable(RunBeforeMCSSteppableBasePy):
    def __init__(self, frequency=1):
        '''
        constructor
        '''    
        SteppableBasePy.__init__(self, frequency)
        

    def start(self):
        '''
        called once before first MCS
        '''
        # PLACE YOUR CODE BELOW THIS LINE

        print("ChemoattractantSecretionSteppable: This function is called once before simulation")

    def step(self, mcs):
        '''
        called every MCS or every "frequency" MCS (depending how it was instantiated in the main Python file)
        '''
        # PLACE YOUR CODE BELOW THIS LINE
    
        print("ChemoattractantSecretionSteppable: This function is called every 1 MCS")
        print("ChemoattractantSecretionSteppable: This function is called before MCS i.e. pixel-copies take place for that MCS ")

        # typical use for this type of steppable is secretion  
        # uncomment lines  below and include Secretion plugin to make commented code work

        CXCL12 = self.get_field_secretor("CXCL12")
        CXCL13 = self.get_field_secretor("CXCL13")

        all_CXCL12_seen = []
        all_CXCL13_seen = []
        
        for cell in self.cell_list:

            if cell.type == 2: #FDC
                
                print("CXCL13_seen = " + str(CXCL13.amountSeenByCell(cell)))

                #CXCL13.secreteInsideCell(cell,3.6)

                # attr_secretor.secreteInsideCellAtBoundary(cell,300)

                # attr_secretor.secreteOutsideCellAtBoundary(cell,500)
                
                CXCL13_seen = CXCL13.amountSeenByCell(cell)
                all_CXCL13_seen.append(CXCL13_seen)
                
                lambda_secretion_13 = 0.1*3.6 * 10**6 / (1 + (CXCL13_seen/100)**6)
                CXCL13.secreteInsideCellAtCOM(cell,lambda_secretion_13)             

            if cell.type == self.CRC: #CRC
                
                print("CXCL12_seen = " + str(CXCL12.amountSeenByCell(cell)))

                #CXCL12.secreteInsideCell(cell,3.6)

                # attr_secretor.secreteInsideCellAtBoundary(cell,300)

                # attr_secretor.secreteOutsideCellAtBoundary(cell,500)
                
                CXCL12_seen = CXCL12.amountSeenByCell(cell)
                all_CXCL12_seen.append(CXCL12_seen)
                
                lambda_secretion_12 = 3.6 * 10**6 / (1 + (CXCL12_seen/100)**6)
                CXCL12.secreteInsideCellAtCOM(cell,3.6)  
        
        
        print("count_CXCL13_seen = " + str(len(all_CXCL13_seen)))
        print("mean_CXCL13_seen = " + str(np.mean(all_CXCL13_seen)))
        print("CV_CXCL13_seen = " + str(np.std(all_CXCL13_seen)/np.mean(all_CXCL13_seen)))
        
        print("count_CXCL12_seen = " + str(len(all_CXCL12_seen)))
        print("mean_CXCL12_seen = " + str(np.mean(all_CXCL12_seen)))
        print("CV_CXCL12_seen = " + str(np.std(all_CXCL12_seen)/np.mean(all_CXCL12_seen)))
"""

