from cc3d import CompuCellSetup

from GCR_48Steppables import GCR_48Steppable
from GCR_48Steppables import MitosisSteppable
from GCR_48Steppables import BCell_GRNSteppable
from GCR_48Steppables import VisualizationSteppable

CompuCellSetup.register_steppable(steppable=GCR_48Steppable(frequency=1))
CompuCellSetup.register_steppable(steppable=MitosisSteppable(frequency=10))
CompuCellSetup.register_steppable(steppable=BCell_GRNSteppable(frequency=1))
CompuCellSetup.register_steppable(steppable=VisualizationSteppable(frequency=1))


# from GCR_48Steppables import ChemoattractantSecretionSteppable
# CompuCellSetup.register_steppable(steppable=ChemoattractantSecretionSteppable(frequency=1))



CompuCellSetup.run()